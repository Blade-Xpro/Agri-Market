﻿SELECT *
FROM [dbo].[FarmerDetails];